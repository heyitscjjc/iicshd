<?php
header("location:login.php");

//TESTING
?>