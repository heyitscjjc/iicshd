credentials

admin: admin
pass: 123123Aa

student: 2015081659
pass: 123123Aa

faculty: 199812313
pass: 123123Aa